import { getResourceState } from './../store/selectors/resource.selector';
import { ResourceState } from './../store/states/resource.state';
import { ResourcePost, ResourceGet } from './../store/actions/resource.actions';
import { IRequest } from './../interfaces/request.interface';
import { Store, select } from '@ngrx/store';
import { AppStateUnion } from './../../store/states/app.state';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { filter, first } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ResourceFacade {

  constructor(
    private _store: Store<AppStateUnion>
  ) {}

  public getResource(identity: string): Observable<ResourceState> {
    return this._store.pipe(
      select( getResourceState ),
      filter((resource: ResourceState) => resource.identity === identity),
      first((resource: ResourceState) => !resource.loading)
    );
  }

  public setPost(request: IRequest) {
    this._store.dispatch(new ResourcePost(request));
  }

  public setGet( request: IRequest ) {
    this._store.dispatch(new ResourceGet( request ));
  }
}
