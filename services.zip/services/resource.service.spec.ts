import { TestBed, inject } from '@angular/core/testing';

import { ResourceService } from './Resource.service';

describe('ResourceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ResourceService]
    });
  });

  it('should be post', inject([ResourceService], (service: ResourceService) => {
    expect(service).toBeTruthy();
  }));
});
