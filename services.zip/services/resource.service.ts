import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';

// ngrx
import { Store } from '@ngrx/store';
import { ResourceState } from './../store/states/resource.state';

// custom
import { ISerializer } from './../interfaces';
import { IRequest } from './../interfaces/request.interface';
import { environment } from './../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ResourceService {

  public url: String = environment.sapEndpoint;
  public endPoint: String = '';
  public serializer: ISerializer;

  private region: string;
  private token: string;
  private usuario: string;

  constructor(
    protected httpClient: HttpClient,
    private store: Store<ResourceState>
  ) {}


  setEndPoint( endPoint ) {
    this.endPoint = endPoint;
  }

  public execute( params: IRequest ): Observable<IRequest> {
    if ( params.hasOwnProperty('endPoint') ) {
      this.endPoint = params['endPoint'];
    }

    if ( params.hasOwnProperty('queryString') ) {
      this.endPoint = this.getEndPoint( params['queryString'] );
    }

    return this.httpClient
      .post<any>(
        `${this.url}/${this.endPoint}`,
        params['body'],
        { params: params.queryString }
      );
  }

  post<T>( entity: T ): Observable<T> {
    this.getStoreInfos();
    if ( entity.hasOwnProperty('endPoint') ) {
      this.endPoint = entity['endPoint'];
    }

    entity['headers'] = this.token;

    this.removeNullParams(entity['queryString']);
    this.removeNullParams(entity['body']);

    const options = {
      headers: { 'x-access-token': this.token },
      params: {
        ...entity['queryString'],
      }
    };
    if ( this.region ) {
      options.params.region = this.region;
    }

    entity['body'].USUARIO = this.usuario;


    return this.httpClient
      .post<any>(`${this.url}/${this.endPoint}`, entity['body'], options );
  }

  get( params ): Observable<Array<any>> {
    return this.getAll( params );
  }

  getOne(): Observable<any> {
    this.getStoreInfos();
    return this.httpClient
      .get(`${this.url}/${this.endPoint}`);
  }

  getAll( _params ): Observable<Array<any>> {
    this.getStoreInfos();

    if ( _params.hasOwnProperty('endPoint') ) {
      this.endPoint = _params['endPoint'];
    }

    if ( _params.hasOwnProperty('queryString') ) {
      this.endPoint = this.getEndPoint( _params['queryString'] );
      this.removeNullParams( _params.queryString );
    }

    const options = {
      headers: { 'x-access-token' : this.token },
      params: {
        ..._params.queryString
      }
    };
    if ( this.region ) {
      options.params.region = this.region;
    }

    return this.httpClient
      .get<Array<any>>(
        `${this.url}/${this.endPoint}`, options );

      // ******* TODO = Tela de insucesso ******
      // .pipe(
      //   retryWhen( genericRetryStrategy({
      //     scalingDuration: 1000,
      //     excludedStatusCodes: [404]
      //   })),
      //   catchError(error => of(error))
      // );
  }

  getOneBy(): Observable<any> {
    this.getStoreInfos();

    return this.httpClient
      .get(`${this.url}/${this.endPoint}`);
  }

  getAllBy(): Observable<Array<any>> {
    this.getStoreInfos();

    return this.httpClient
      .get<Array<any>>(`${this.url}/${this.endPoint}`);
  }

  put<T>( entity: T ): Observable<T> {
    this.getStoreInfos();
    if ( entity.hasOwnProperty('endPoint') ) {
      this.endPoint = entity['endPoint'];
    }

    this.removeNullParams(entity['queryString']);
    this.removeNullParams(entity['body']);

    const options = {
      headers: { 'x-access-token': this.token },
      params: {
        ...entity['queryString'],
      }
    };
    if ( this.region ) {
      options.params.region = this.region;
    }

    return this.httpClient
      .put<any>(`${this.url}/${this.endPoint}`, entity['body'], options );
  }

  delete<T>( entity: T ): Observable<T> {
    this.getStoreInfos();
    if ( entity.hasOwnProperty('endPoint') ) {
      this.endPoint = entity['endPoint'];
    }

    const options = {
      headers: { 'x-access-token': this.token },
      params: {
        ...entity['queryString'],
      }
    };
    if ( this.region ) {
      options.params.region = this.region;
    }

    return this.httpClient
      .delete<T>(`${this.url}/${this.endPoint}`, options);
  }

  getQueryString( queryString: any ): string {
    return '?' + Object.keys(queryString).map(key => key + '=' + queryString[key]).join('&');
  }

  getEndPoint( params: any ): String {
    let endPoint: String = this.endPoint;
    Object.keys(params).forEach( key => { endPoint = endPoint['replaceAll']( key, params[key] ); });
    return endPoint;
  }

  getStoreInfos() {
    this.store.select('dashboard', 'sap').subscribe( state => {
      this.region = ( state && state.ESTADO ) ? state.ESTADO : null;
    });

    this.store.select('login').subscribe( login => {
      this.token = login.token;
      this.usuario = login.id;
    });
  }



  private removeNullParams( obj: any) {
    for ( const prop in obj ) {
      if ( obj[prop] && obj[prop].length <= 0 ) {
        delete obj[ prop ];
      }
    }

  }
}

